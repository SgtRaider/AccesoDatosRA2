package com.raider.principal.util;

import java.io.File;

/**
 * Created by raider on 5/11/15.
 */

// Variables generales

public class Values {

    public static int tpConstant = 0;
    public static boolean modifyConstant = false;
    public static int idCuartel;
    public static int idUnidad;
    public static int idSoldado;
    public static String driver = "com.mysql.jdbc.Driver";
    public static boolean warningBaseDatos = false;
    public static String claveSeguridad = "20111956";
}
