package com.raider.principal.Util;

import java.io.File;

/**
 * Created by raider on 5/11/15.
 */

// Variables generales

public class Values {

    public static int tpConstant = 0;
    public static boolean modifyConstant = false;
    public static String PATHmod = "";
    public static String PATH = System.getProperty("user.home") + File.separator + "ArchivoEjercito.dat";
    public static int idCuartel;
    public static int idUnidad;
    public static int idSoldado;
}
